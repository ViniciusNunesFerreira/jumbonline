<div>
    <form
        x-data="{ dirty: new Set(), date: new Date(), published_at: @entangle('published_at'), scheduled_at: null }"
        x-init="flatpickr($refs.date, {
            enableTime: true,
            dateFormat: 'Z',
            minDate: Date.now(),
            defaultHour: date.getHours(),
            defaultMinute: date.getMinutes(),
            disableMobile: true,
            plugins: [new confirmDatePlugin({
                confirmIcon: '',
                confirmText: '{{ __('Schedule availability') }}',
                showAlways: true
            })],
            onClose: function(date, dateString) {
                if (dateString !== undefined) {
                    published_at = dateString;
                    scheduled_at = dateString;
                    dirty.add('schedule_at');
                }
            }
        })"
        x-on:product-status-updated.window="dirty.clear()"
        wire:submit.prevent="save"
    >
        <x-card>
            <x-slot:header>
                <div class="-ml-4 -mt-2 flex items-center justify-between flex-wrap sm:flex-nowrap">
                    <div class="ml-4 mt-2">
                        <h3 class="text-base font-medium text-slate-900 dark:text-slate-200">
                            {{ __('Status do Produto') }}
                        </h3>
                    </div>
                    <div
                        x-show="dirty.size >= 1"
                        class="ml-4 mt-2 flex-shrink-0"
                    >
                        <button
                            type="submit"
                            class="btn btn-link"
                        >
                            {{ __('Salvar') }}
                        </button>
                    </div>
                </div>
            </x-slot:header>
            <x-slot:content class="-mt-5">

                

                <x-select
                    x-on:change="$nextTick(() => $el.value !== '{{ $product->status->name }}' ? dirty.add('status') : dirty.delete('status'))"
                    wire:model="product.status"
                    class="sm:text-sm"
                >
                    @foreach(\App\Enums\ProductStatus::cases() as $status)
                        <option value="{{ $status->name }}">{{ $status->label() }}</option>
                    @endforeach
                </x-select>

                
                <div class="mt-2 sm:text-sm">
                    <div class="text-slate-500 text-sm dark:text-slate-400">
                        @if($published_at && \Carbon\Carbon::parse($published_at)->isFuture())
                            <p>
                                {{ __('Agendado para ') }}
                                <span x-text="scheduled_at ? new Date(scheduled_at) : new Date(Date.parse(published_at + ' {{ config('app.timezone') }}'))"></span>
                            </p>

                            @if($product->status->name !== \App\Enums\ProductStatus::ACTIVE->name)
                                <p class="mt-1">
                                    {{ __('O agendamento não será aplicado até que o status do produto seja definido como ativo.') }}
                                </p>
                            @endif
                        @endif
                    </div>
                    <div class="mt-1 space-x-3">
                        @if($published_at && \Carbon\Carbon::parse($published_at)->isFuture())
                            <span
                                x-ref="date"
                                class="btn btn-link cursor-pointer"
                            >
                                {{ __('Editar') }}
                            </span>
                            <a
                                role="button"
                                x-on:click="published_at = new Date(); scheduled_at = null; dirty.add('schedule_at');"
                                class="btn btn-link cursor-pointer"
                            >
                                {{ __('Limpar Agendamento') }}
                            </a>
                        @else
                            <span
                                x-ref="date"
                                class="btn btn-link cursor-pointer"
                            >
                                {{ __('Agendar Publicação') }}
                            </span>
                        @endif
                    </div>
                </div>


                
                <div class="mt-2">

                    <x-input-label> Tipo de Produto </x-input-label>
                    

                    <x-select
                        x-on:change="$nextTick(() => $el.value !== '{{ $product->type->name }}' ? dirty.add('status') : dirty.delete('status'))"
                        wire:model="product.type"
                        class="sm:text-sm mt-2"
                    >
                        @foreach(\App\Enums\ProductType::cases() as $type)
                            <option value="{{ $type->name }}">{{ $type->label() }}</option>
                        @endforeach
                    </x-select>
                </div>

            </x-slot:content>
        </x-card>
    </form>
</div>
